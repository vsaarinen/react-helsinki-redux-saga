# Presentation: Real-life experiences with redux-saga

A presentation held at [React Helsinki](https://meetabit.com/communities/react-helsinki) meetup on 22.2.2017.

See the slides [here](https://vsaarinen.github.io/react-helsinki-redux-saga/).
